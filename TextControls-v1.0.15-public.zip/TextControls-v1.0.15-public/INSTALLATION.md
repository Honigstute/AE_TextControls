# Installation

## Install The Panel

1. Install `TextControls-v1.0.15.zxp` with your preferred CEP/ZXP installer.
2. Open Adobe After Effects.
3. Open the panel:

`Window -> Extensions -> Text Controls`

## First Launch

The panel has two transcription paths:

### Option 1: OpenAI Whisper API

Best for the easiest setup.

Requirements:

- OpenAI API key

Recommended setup:

1. Open `Transcribe Settings`
2. Set `Engine` to `OpenAI Whisper API`
3. For comp transcription, keep `OpenAI Render` on `Slow Render (compatibility)`
4. Paste your API key
5. Click `Check Setup`

Notes:

- `Slow Render (compatibility)` does not require local Whisper
- `Slow Render (compatibility)` does not require Python
- `Slow Render (compatibility)` does not require ffmpeg

### Option 2: Local Whisper

Best for offline/local transcription.

Requirements:

- Python 3
- Whisper installed with `python3 -m pip install openai-whisper` on macOS or `py -m pip install openai-whisper` on Windows
- ffmpeg available on your system `PATH`

Notes:

- on macOS, install a real Python first
- the macOS system `python3` stub can open an Apple developer-tools prompt and is not a full Python install
- `brew install ffmpeg` only works after Homebrew itself is installed
- Homebrew's official install path requires Apple Command Line Tools
- if you want the lowest-friction setup, use `OpenAI Whisper API` with `Slow Render (compatibility)`

Setup:

1. Open `Transcribe Settings`
2. Set `Engine` to `Local Whisper`
3. Click `Check Setup`
4. Install anything the panel reports as missing
5. Run `Check Setup` again

## Sources

The panel supports:

- `Selected Comp`
- `Audio / Video File (mp3, mp4)`

Meaning:

- if your audio is already a file, you can transcribe it directly
- if the audio only exists in the comp mix, the panel will create a temporary export automatically

## Troubleshooting

### Transcribe button stays disabled

- run `Check Setup`
- confirm your API key is valid in OpenAI mode
- confirm a file is selected when using file source
- confirm local dependencies are installed in Local Whisper mode

### OpenAI comp transcription fails

- use `Slow Render (compatibility)` first
- if you want `Fast Render`, install `ffmpeg`

### Local Whisper setup fails

Make sure these commands work on your machine:

- `python3` or `python` or `py`
- `whisper`
- `ffmpeg`
