# Upload Copy

## Product Title

`Text Controls for After Effects`

## Short Description

`Transcribe, import, animate, and split subtitles inside After Effects.`

## Medium Description

`Text Controls is an After Effects CEP panel for subtitle and text workflows. It can transcribe selected comp audio or external media files, import SRT subtitles, build highlight-based subtitle animation, and decompose text into words or letters.`

## Long Description

`Text Controls is a CEP panel for Adobe After Effects focused on subtitle and text workflows. You can transcribe a selected comp, transcribe an external audio or video file, import SRT subtitles, create animated highlight-based subtitle layouts, and decompose text into words or letters.`

`There are two transcription paths. OpenAI Whisper API is the easiest cloud option. In Slow Render mode it only needs an API key, so users do not need to install Python, Whisper, or ffmpeg. Local Whisper is the offline option and requires Python 3, openai-whisper, and ffmpeg.`

`The plugin includes a built-in Setup Check that validates the selected workflow before transcription starts. It also supports direct media-file transcription, so if your audio already exists as a file you do not need to render a comp manually first.`

## Short Video Description

`Text Controls for After Effects lets you transcribe comp audio or media files, import SRT subtitles, build highlight-based subtitle animation, and decompose text layers into words or letters.`

`OpenAI mode can run with only an API key in Slow Render mode, while Local Whisper gives you a fully offline option with Python, Whisper, and ffmpeg installed.`

## Longer Video Description

`Text Controls is a CEP panel for Adobe After Effects focused on subtitle and text workflows. You can transcribe a selected comp, transcribe an external audio or video file, import SRT subtitles, create animated highlight-based subtitle layouts, and decompose text into words or letters.`

`There are two transcription paths. OpenAI Whisper API is the easiest cloud option. In Slow Render mode it only needs an API key, so users do not need to install Python, Whisper, or ffmpeg. Local Whisper is the offline option and requires Python 3, openai-whisper, and ffmpeg.`

`The plugin includes a built-in Setup Check that validates the selected workflow before transcription starts. It also supports direct media-file transcription, so if your audio already exists as a file you do not need to render a comp manually first.`

## Feature Bullets

- Transcribe selected comp audio
- Transcribe external audio and video files
- OpenAI Whisper API support
- Local Whisper support
- SRT import
- Highlight animation subtitle mode
- Word and letter decomposition
- Reusable text layout presets

## Suggested Tags

- `After Effects`
- `Subtitles`
- `Transcription`
- `Whisper`
- `OpenAI`
- `Motion Design`
- `CEP Panel`
- `Text Animation`
