# Release Notes

## Text Controls v1.0.15

Browse-button compatibility refresh. Local `Whisper` and `ffmpeg` path picking now follows the same file-input style as the working media-file picker, which is more reliable across different After Effects builds and Macs.

### Included

- Signed `ZXP` package
- Bundled panel icons
- Install guide
- Upload/store/video copy

### Core Features

- OpenAI Whisper API transcription
- Local Whisper transcription
- Selected comp audio transcription
- External audio/video file transcription
- SRT import
- Focused highlight animation mode
- Word and letter decomposition
- Preset capture and reuse

### Notes

- Best beginner setup: `OpenAI Whisper API` + `Slow Render (compatibility)`
- Offline/local setup requires `Python 3`, `openai-whisper`, and `ffmpeg`
- `Whisper` and `ffmpeg` path browsing now uses the same picker style as `Audio / Video File`
