# Release Notes

## Text Controls v1.0.6

Public installer refresh with separate Whisper and ffmpeg executable pickers plus more compatible native dropdown behavior.

### Included

- Signed `ZXP` package
- Bundled panel icons
- Install guide
- Upload/store/video copy

### Core Features

- OpenAI Whisper API transcription
- Local Whisper transcription
- Selected comp audio transcription
- External audio/video file transcription
- SRT import
- Focused highlight animation mode
- Word and letter decomposition
- Preset capture and reuse

### Notes

- Best beginner setup: `OpenAI Whisper API` + `Slow Render (compatibility)`
- Offline/local setup requires `Python 3`, `openai-whisper`, and `ffmpeg`
